const fs = require('graceful-fs');
// Use `fs` as you would normally use `fs`
